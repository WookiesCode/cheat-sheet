// eth-ethtool-tuning.js
// Standalone interactive cheat sheet for Ethernet: ethtool Link Speed, Offloads & Ring Buffers
const ETH_ETH_ETHTOOL_TUNING_DATA = [
  {
    "id": "ethtool-phy-tuning-cmd-1",
    "badge": "eth",
    "title": "ethtool & Ring Buffers: Check negotiated link speed, duplex, auto-negotiation, and link partner advertised speeds",
    "subtitle": "Check negotiated link speed, duplex, auto-negotiation, and link partner advertised speeds",
    "commands": [
      {
        "id": "ethtool-link-speed-autoneg",
        "desc": "Check negotiated link speed, duplex, auto-negotiation, and link partner advertised speeds",
        "cmd": "ethtool eth0   |   ethtool -r eth0   |   ethtool -s eth0 speed 1000 duplex full autoneg on",
        "details": "",
        "flags": [
          [
            "Link detected: yes/no",
            "Physical layer carrier lock status"
          ],
          [
            "Link partner advertised link modes",
            "Shows what speeds/duplex the upstream switch port is offering"
          ],
          [
            "ethtool -r <iface>",
            "Restart auto-negotiation on the interface"
          ]
        ],
        "tip": "",
        "tags": [
          "ethtool & Ring Buffers",
          "ethernet",
          "nic",
          "networking",
          "linux",
          "speed",
          "duplex",
          "autoneg",
          "ethtool",
          "carrier",
          "1000base-t"
        ]
      }
    ]
  },
  {
    "id": "ethtool-phy-tuning-flags-1",
    "badge": "eth",
    "title": "ethtool & Ring Buffers: Arguments & Parameters",
    "subtitle": "Key arguments, parameters, and filtering options for Check negotiated link speed, duplex, auto-negotiation, and link partner advertised speeds",
    "commands": [
      {
        "id": "ethtool-link-speed-autoneg-flags-card",
        "desc": "Options breakdown and parameter syntax for Check negotiated link speed, duplex, auto-negotiation, and link partner advertised speeds",
        "cmd": "ethtool eth0   |   ethtool -r eth0   |   ethtool -s eth0 speed 1000 duplex full autoneg on",
        "flags": [
          [
            "Note on 1000BASE-T",
            "IEEE 802.3ab requires autoneg ON for 1000BASE-T (to negotiate Master/Slave clock timing)"
          ]
        ],
        "details": "Common operational and diagnostic parameters for Linux Ethernet networking.",
        "tags": [
          "ethtool & Ring Buffers",
          "flags",
          "options",
          "syntax"
        ]
      }
    ]
  },
  {
    "id": "ethtool-phy-tuning-cmd-2",
    "badge": "eth",
    "title": "ethtool & Ring Buffers: Inspect hardware NIC MAC/PHY counters for bad cables",
    "subtitle": "Inspect hardware NIC MAC/PHY counters for bad cables (`rx_crc_errors`), ring drops, or pause frames",
    "commands": [
      {
        "id": "ethtool-crc-drop-counters",
        "desc": "Inspect hardware NIC MAC/PHY counters for bad cables (`rx_crc_errors`), ring drops, or pause frames",
        "cmd": "ethtool -S eth0 | grep -iE 'err|drop|crc|fcs|align|miss|fifo|over|pause' | grep -v ': 0'",
        "details": "",
        "flags": [
          [
            "rx_crc_errors / rx_fcs_errors",
            "Physical layer bit corruption (bad RJ45 crimp, EMI, damaged patch cable, or dirty optic)"
          ],
          [
            "rx_missed_errors / rx_no_buffer",
            "NIC dropped packets because host CPU/ring buffer couldn't drain frames fast enough"
          ],
          [
            "tx_pause / rx_pause",
            "802.3x flow-control pause frames throttling traffic"
          ]
        ],
        "tip": "rx_crc_errors > 0 = replace cable",
        "tags": [
          "ethtool & Ring Buffers",
          "ethernet",
          "nic",
          "networking",
          "linux",
          "crc",
          "fcs",
          "errors",
          "drops",
          "counters",
          "pause",
          "ethtool"
        ]
      }
    ]
  },
  {
    "id": "ethtool-phy-tuning-cmd-3",
    "badge": "eth",
    "title": "ethtool & Ring Buffers: Inspect and increase NIC RX/TX descriptor ring buffers and multi-queue RSS channels",
    "subtitle": "Inspect and increase NIC RX/TX descriptor ring buffers and multi-queue RSS channels",
    "commands": [
      {
        "id": "ethtool-ring-buffers-queues",
        "desc": "Inspect and increase NIC RX/TX descriptor ring buffers and multi-queue RSS channels",
        "cmd": "ethtool -g eth0   |   ethtool -G eth0 rx 4096 tx 4096   |   ethtool -l eth0   |   ethtool -L eth0 combined 16",
        "details": "",
        "flags": [
          [
            "-g / -G",
            "Show / Set RX & TX ring buffer size (increasing from 512 to 4096 prevents microburst packet drops)"
          ],
          [
            "-l / -L",
            "Show / Set number of multi-queue RSS channels (spreads IRQ softirq load across CPU cores)"
          ],
          [
            "ethtool -k eth0",
            "Inspect hardware offloads (tcp-segmentation-offload, generic-receive-offload, rx-checksumming)"
          ]
        ],
        "tip": "",
        "tags": [
          "ethtool & Ring Buffers",
          "ethernet",
          "nic",
          "networking",
          "linux",
          "ring",
          "buffer",
          "rss",
          "queues",
          "offload",
          "tso",
          "gro",
          "drops"
        ]
      }
    ]
  },
  {
    "id": "ethtool-phy-tuning-cmd-4",
    "badge": "eth",
    "title": "ethtool & Ring Buffers: Identify kernel driver",
    "subtitle": "Identify kernel driver (`igb`, `ixgbe`, `i40e`, `ice`, `mlx5_core`, `r8169`), NIC firmware & PCI bus address",
    "commands": [
      {
        "id": "ethtool-driver-pci-bdf",
        "desc": "Identify kernel driver (`igb`, `ixgbe`, `i40e`, `ice`, `mlx5_core`, `r8169`), NIC firmware & PCI bus address",
        "cmd": "ethtool -i eth0   |   lspci -nnk | grep -A3 -i net",
        "details": "",
        "flags": [
          [
            "driver / version / firmware-version",
            "Prints kernel module name, driver version, and NIC NVM/EEPROM firmware version"
          ],
          [
            "bus-info",
            "Prints exact PCI BDF (e.g. 0000:04:00.0) to correlate with lspci -vvv"
          ]
        ],
        "tip": "",
        "tags": [
          "ethtool & Ring Buffers",
          "ethernet",
          "nic",
          "networking",
          "linux",
          "driver",
          "firmware",
          "pci",
          "bdf",
          "lspci",
          "ixgbe",
          "mlx5"
        ]
      }
    ]
  },
  {
    "id": "ethtool-phy-tuning-pro-tips",
    "badge": "tip",
    "title": "ethtool & Ring Buffers: Pro Tips & Best Practices",
    "subtitle": "NIC Descriptor Ring Buffering & Hardware Packet Drop Elimination",
    "commands": [
      {
        "id": "ethtool-phy-tuning-tips-card",
        "desc": "NIC Descriptor Ring Buffering & Hardware Packet Drop Elimination",
        "cmd": "ethtool -S eth0 | grep -E \"(drop|error|miss)\" && ethtool -G eth0 rx 4096 tx 4096",
        "details": "Default kernel NIC RX ring buffers (often 512 or 1024 descriptors) easily overflow during microbursts in high-throughput AI/ML and storage clusters, manifesting as \"rx_dropped\" or \"rx_no_buffer_count\". Maximize ring buffers to 4096 or 8192 descriptors to absorb line-rate burst transitions before packets hit kernel softirqs.",
        "flags": [
          [
            "ethtool -S <dev>",
            "Dump comprehensive low-level hardware MAC/PHY statistics and error counters"
          ],
          [
            "ethtool -G <dev> rx 4096 tx 4096",
            "Expand ring buffer descriptor depth to prevent microburst drops"
          ],
          [
            "ethtool -k <dev>",
            "Inspect status of hardware offloads (TSO, GSO, GRO, checksum offloading)"
          ]
        ],
        "tip": "High \"rx_crc_errors\" indicates damaged patch cables or dirty transceiver pins, while \"rx_missed_errors\" points to PCIe host bus bandwidth bottlenecks.",
        "tags": [
          "ethtool-phy-tuning",
          "tips",
          "pro",
          "ethernet",
          "nic",
          "best-practice"
        ]
      }
    ]
  }
];

// Application State
const state = {
  searchQuery: "",
  activeCategory: "all",
  savedOnly: false,
  compact: localStorage.getItem("linux_cs_compact") === "1",
  theme: localStorage.getItem("linux_cs_theme") || "dark",
  bookmarks: new Set(JSON.parse(localStorage.getItem("eth-ethtool-tuning_bookmarks") || "[]"))
};

// DOM Elements
const searchInput = document.getElementById("search-input");
const categoryTabsEl = document.getElementById("category-tabs");
const sectionsContainer = document.getElementById("sections-container");
const visibleCountEl = document.getElementById("visible-count");
const emptyStateEl = document.getElementById("empty-state");
const savedFilterBtn = document.getElementById("saved-filter-btn");
const savedCountEl = document.getElementById("saved-count");
const densityToggleBtn = document.getElementById("density-toggle");
const densityLabel = document.getElementById("density-label");
const printBtn = document.getElementById("print-btn");
const themeToggleBtn = document.getElementById("theme-toggle");
const resetSearchBtn = document.getElementById("reset-search-btn");
const toastEl = document.getElementById("toast");
const toastTextEl = document.getElementById("toast-text");

let toastTimer = null;

function escapeHtml(str) {
  if (str == null) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function showToast(msg) {
  if (!toastEl) return;
  toastTextEl.textContent = msg;
  toastEl.classList.add("visible");
  toastEl.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    toastEl.classList.remove("visible");
    toastEl.classList.remove("show");
  }, 2200);
}

function copyToClipboard(text) {
  if (window.AntigravityCommon && typeof window.AntigravityCommon.substituteVariables === "function") {
    const subResult = window.AntigravityCommon.substituteVariables(text);
    text = subResult.text;
  }
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(() => {
      showToast("Copied: " + (text.length > 40 ? text.slice(0, 38) + "..." : text));
    }).catch(() => fallbackCopy(text));
  } else {
    fallbackCopy(text);
  }
}

function fallbackCopy(text) {
  const ta = document.createElement("textarea");
  ta.value = text;
  document.body.appendChild(ta);
  ta.select();
  document.execCommand("copy");
  document.body.removeChild(ta);
  showToast("Copied: " + (text.length > 40 ? text.slice(0, 38) + "..." : text));
}

// Ethernet Command Syntax Highlighting
function highlightCommand(raw) {
  const escaped = raw
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");

  return escaped.replace(
    /(^|\s|;|&&|\|\||\|)(sudo\s+)?([a-zA-Z0-9_.-]+)|('[^']*'|"[^"]*")|(\s--?[a-zA-Z0-9_-]+(?:=[a-zA-Z0-9_.,*/:-]+)?)|(\|\||&&|\|)/g,
    (match, lead, sudoPart, cmdName, strLiteral, flagPart, operatorPart) => {
      if (strLiteral) return '<span class="tok-str">' + strLiteral + '</span>';
      if (flagPart) return '<span class="tok-flag">' + flagPart + '</span>';
      if (operatorPart) return '<span class="tok-pipe">' + operatorPart + '</span>';
      if (cmdName) {
        const prefix = lead || "";
        const sudoHtml = sudoPart ? '<span class="tok-pipe">' + sudoPart + '</span>' : "";
        return prefix + sudoHtml + '<span class="tok-cmd">' + cmdName + '</span>';
      }
      return match;
    }
  );
}

function renderCategoryTabs() {
  const allCards = ETH_ETH_ETHTOOL_TUNING_DATA;
  const totalCmds = allCards.reduce((acc, c) => acc + c.commands.length, 0);

  const optionsHtml = [
    '<option value="all"' + (state.activeCategory === "all" ? " selected" : "") + '>All Topics (' + totalCmds + ' items)</option>'
  ];

  for (const card of allCards) {
    const isSelected = state.activeCategory === card.id ? " selected" : "";
    optionsHtml.push(
      '<option value="' + escapeHtml(card.id) + '"' + isSelected + '>' +
      escapeHtml(card.title) + ' (' + card.commands.length + ')' +
      '</option>'
    );
  }

  const resetBtnHtml = state.activeCategory !== "all"
    ? '<button type="button" class="cat-reset-btn" id="cat-reset-btn" title="Show all topics">✕ Show All</button>'
    : "";

  categoryTabsEl.innerHTML =
    '<div class="cat-dropdown-wrap">' +
      '<label class="cat-dropdown-label" for="category-select">Topic:</label>' +
      '<select id="category-select" class="cat-select" aria-label="Filter by topic">' +
        optionsHtml.join("") +
      '</select>' +
      resetBtnHtml +
    '</div>';

  const catSelect = document.getElementById("category-select");
  if (catSelect) {
    catSelect.addEventListener("change", (e) => {
      state.activeCategory = e.target.value;
      renderCategoryTabs();
      renderSections();
    });
  }

  const catReset = document.getElementById("cat-reset-btn");
  if (catReset) {
    catReset.addEventListener("click", () => {
      state.activeCategory = "all";
      renderCategoryTabs();
      renderSections();
    });
  }
}

function matchesSearch(cmd, searchTerms) {
  if (!searchTerms.length) return true;
  const target = [
    cmd.cmd || "",
    cmd.desc || "",
    cmd.details || "",
    cmd.tip || "",
    (cmd.tags || []).join(" "),
    (cmd.flags || []).map(([f, d]) => f + " " + d).join(" ")
  ].join(" ").toLowerCase();

  return searchTerms.every(term => target.includes(term));
}

let allRenderedCards = [];
function packMasonry() {
  if (!sectionsContainer) return;
  if (sectionsContainer.querySelectorAll(".section-card").length === 0) {
    allRenderedCards = [];
    return;
  }
  const directCards = [...sectionsContainer.querySelectorAll(":scope > .section-card")];
  if (directCards.length > 0) {
    allRenderedCards = directCards;
  }
  if (allRenderedCards.length === 0) return;

  const containerWidth = sectionsContainer.clientWidth || window.innerWidth;
  const colCount = Math.max(1, Math.min(allRenderedCards.length, Math.floor((containerWidth + 18) / (380 + 18))));
  if (colCount <= 1) {
    sectionsContainer.classList.remove("has-masonry");
    sectionsContainer.replaceChildren(...allRenderedCards);
    return;
  }

  sectionsContainer.classList.add("has-masonry");

  const cols = Array.from({ length: colCount }, () => {
    const col = document.createElement("div");
    col.className = "masonry-col";
    return col;
  });
  const colHeights = new Array(colCount).fill(0);
  sectionsContainer.replaceChildren(...cols);

  for (const card of allRenderedCards) {
    let shortestIdx = 0;
    for (let i = 1; i < colCount; i++) {
      if (colHeights[i] < colHeights[shortestIdx]) {
        shortestIdx = i;
      }
    }
    cols[shortestIdx].appendChild(card);
    colHeights[shortestIdx] += card.offsetHeight + 18;
  }
}

let masonryResizeTimer = null;
window.addEventListener("resize", () => {
  clearTimeout(masonryResizeTimer);
  masonryResizeTimer = setTimeout(packMasonry, 40);
});
document.addEventListener("fullscreenchange", () => {
  clearTimeout(masonryResizeTimer);
  masonryResizeTimer = setTimeout(packMasonry, 40);
});
document.addEventListener("webkitfullscreenchange", () => {
  clearTimeout(masonryResizeTimer);
  masonryResizeTimer = setTimeout(packMasonry, 40);
});
window.packMasonry = packMasonry;

function renderSections() {
  let visibleCommandsCount = 0;
  const cardsHtml = [];

  for (const card of ETH_ETH_ETHTOOL_TUNING_DATA) {
    if (state.activeCategory !== "all" && state.activeCategory !== card.id) {
      continue;
    }

    const searchTerms = state.searchQuery
      .trim()
      .toLowerCase()
      .split(/\s+/)
      .filter(Boolean);

    const filteredCommands = card.commands.filter((cmd) => {
      if (state.savedOnly && !state.bookmarks.has(cmd.id)) return false;
      return matchesSearch(cmd, searchTerms);
    });

    if (filteredCommands.length === 0) continue;
    visibleCommandsCount += filteredCommands.length;

    const commandsHtml = filteredCommands.map((cmd) => {
      const isBookmarked = state.bookmarks.has(cmd.id);

      const flagsHtml = (cmd.flags && cmd.flags.length > 0)
        ? '<div class="flag-pills">' + cmd.flags.map(([f, d]) =>
            '<span class="flag-pill"><strong class="flag-token">' + escapeHtml(f) + '</strong> <span class="flag-desc">' + escapeHtml(d) + '</span></span>'
          ).join("") + '</div>'
        : "";

      const detailsHtml = cmd.details
        ? '<p class="cmd-details">' + escapeHtml(cmd.details) + '</p>'
        : "";

      const tipHtml = cmd.tip
        ? '<div class="cmd-tip"><span class="tip-badge">TIP</span>' + escapeHtml(cmd.tip) + '</div>'
        : "";

      const copyTarget = cmd.cmd.includes("   |   ")
        ? cmd.cmd.split("   |   ")[0].trim()
        : cmd.cmd.trim();

      return [
        '<div class="cmd-item" id="cmd-' + escapeHtml(cmd.id) + '" data-cmd-id="' + escapeHtml(cmd.id) + '">',
        '  <div class="cmd-header-row">',
        '    <div class="cmd-desc">',
        '      <span>' + escapeHtml(cmd.desc) + '</span>',
        '    </div>',
        '    <button',
        '      type="button"',
        '      class="bookmark-btn ' + (isBookmarked ? "bookmarked" : "") + '"',
        '      data-cmd-id="' + escapeHtml(cmd.id) + '"',
        '      title="' + (isBookmarked ? "Remove bookmark" : "Bookmark this command") + '"',
        '      aria-label="' + (isBookmarked ? "Remove bookmark" : "Bookmark this command") + '"',
        '    >',
        '      <svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true">',
        '        <path fill="' + (isBookmarked ? "currentColor" : "none") + '" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>',
        '      </svg>',
        '    </button>',
        '  </div>',
        '',
        '  <div class="cmd-code-box" data-cmd="' + escapeHtml(copyTarget) + '" title="Click to copy command">',
        '    <pre class="cmd-code"><code>' + highlightCommand(cmd.cmd) + '</code></pre>',
        '    <button type="button" class="copy-btn" title="Copy command" aria-label="Copy command">',
        '      <svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true">',
        '        <rect x="9" y="9" width="13" height="13" rx="2" fill="none" stroke="currentColor" stroke-width="2"/>',
        '        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" fill="none" stroke="currentColor" stroke-width="2"/>',
        '      </svg>',
        '      <span class="copy-feedback">Copy</span>',
        '    </button>',
        '  </div>',
        '  ' + detailsHtml,
        '  ' + flagsHtml,
        '  ' + tipHtml,
        '</div>'
      ].join("\n");
    }).join("\n");

    cardsHtml.push([
      '<article class="section-card" id="sec-' + escapeHtml(card.id) + '">',
      '  <header class="section-header">',
      '    <div class="section-title-wrap">',
      '      <span class="section-badge">' + escapeHtml(card.badge) + '</span>',
      '      <div>',
      '        <h2 class="section-title">' + escapeHtml(card.title) + '</h2>',
      '        <p class="section-subtitle">' + escapeHtml(card.subtitle) + '</p>',
      '      </div>',
      '    </div>',
      '    <span class="count-badge">' + filteredCommands.length + '</span>',
      '  </header>',
      '  <div class="command-list">',
      commandsHtml,
      '  </div>',
      '</article>'
    ].join("\n"));
  }

  sectionsContainer.innerHTML = cardsHtml.join("\n");
  visibleCountEl.textContent = visibleCommandsCount;

  if (visibleCommandsCount === 0) {
    emptyStateEl.classList.remove("hidden");
  } else {
    emptyStateEl.classList.add("hidden");
  }

  packMasonry();
}

function updateSavedCount() {
  savedCountEl.textContent = state.bookmarks.size;
  if (state.bookmarks.size > 0) {
    savedFilterBtn.classList.add("has-saved");
  } else {
    savedFilterBtn.classList.remove("has-saved");
  }
}

function initEventListeners() {
  searchInput.addEventListener("input", (e) => {
    state.searchQuery = e.target.value;
    renderSections();
  });

  resetSearchBtn.addEventListener("click", () => {
    state.searchQuery = "";
    state.savedOnly = false;
    state.activeCategory = "all";
    searchInput.value = "";
    savedFilterBtn.classList.remove("active");
    renderCategoryTabs();
    renderSections();
    searchInput.focus();
  });

  savedFilterBtn.addEventListener("click", () => {
    state.savedOnly = !state.savedOnly;
    savedFilterBtn.classList.toggle("active", state.savedOnly);
    renderSections();
  });

  densityToggleBtn.addEventListener("click", () => {
    state.compact = !state.compact;
    document.body.classList.toggle("compact-mode", state.compact);
    densityLabel.textContent = state.compact ? "Normal" : "Compact";
    localStorage.setItem("linux_cs_compact", state.compact ? "1" : "0");
    packMasonry();
  });

  if (printBtn) printBtn.addEventListener("click", () => {
    window.print();
  });

  themeToggleBtn.addEventListener("click", () => {
    state.theme = state.theme === "dark" ? "light" : "dark";
    applyTheme(state.theme);
    localStorage.setItem("linux_cs_theme", state.theme);
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "/" && document.activeElement !== searchInput) {
      e.preventDefault();
      searchInput.focus();
      searchInput.select();
    } else if (e.key === "Escape" && document.activeElement === searchInput) {
      searchInput.value = "";
      state.searchQuery = "";
      renderSections();
      searchInput.blur();
    }
  });

  sectionsContainer.addEventListener("click", (e) => {
    const copyBtn = e.target.closest(".copy-btn");
    if (copyBtn) {
      const codeBox = copyBtn.closest(".cmd-code-box");
      const cmdText = codeBox ? codeBox.getAttribute("data-cmd") : "";
      if (cmdText) copyToClipboard(cmdText);
      return;
    }

    const codeBox = e.target.closest(".cmd-code-box");
    if (codeBox && !e.target.closest(".copy-btn")) {
      const cmdText = codeBox.getAttribute("data-cmd");
      if (cmdText) copyToClipboard(cmdText);
      return;
    }

    const bookmarkBtn = e.target.closest(".bookmark-btn");
    if (bookmarkBtn) {
      const cmdId = bookmarkBtn.getAttribute("data-cmd-id");
      if (cmdId) {
        if (state.bookmarks.has(cmdId)) {
          state.bookmarks.delete(cmdId);
          bookmarkBtn.classList.remove("bookmarked");
        } else {
          state.bookmarks.add(cmdId);
          bookmarkBtn.classList.add("bookmarked");
        }
        localStorage.setItem("eth-ethtool-tuning_bookmarks", JSON.stringify([...state.bookmarks]));
        updateSavedCount();
        if (state.savedOnly) renderSections();
      }
      return;
    }
  });
}

function applyTheme(theme) {
  state.theme = theme;
  if (window.CheatSheetCommon && typeof window.CheatSheetCommon.applyTheme === "function") {
    window.CheatSheetCommon.applyTheme(theme);
  } else {
    document.documentElement.setAttribute("data-theme", theme);
    try { localStorage.setItem("linux_cs_theme", theme); } catch (e) {}
  }
}

function init() {
  applyTheme(state.theme);
  if (state.compact) {
    document.body.classList.add("compact-mode");
    densityLabel.textContent = "Normal";
  }
  updateSavedCount();
  renderCategoryTabs();
  renderSections();
  initEventListeners();
}

document.addEventListener("DOMContentLoaded", init);
